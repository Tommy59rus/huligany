#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rules.py — загрузка/создание правил ip_rules.json и subnet_rules.json
"""

import json
import os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
IP_RULES_FILE = os.path.join(SCRIPT_DIR, "ip_rules.json")
SUBNET_RULES_FILE = os.path.join(SCRIPT_DIR, "subnet_rules.json")

DEFAULT_IP_RULES = [
    {
        "condition": "AbuseScore >= 80",
        "description": "Очень высокая репутационная угроза (AbuseIPDB)"
    },
    {
        "condition": "Feodo_Original == 1",
        "description": "IP является C&C-сервером ботнета"
    },
    {
        "condition": "firehol_level1 == 1",
        "description": "IP в основном списке FireHOL"
    },
    {
        "condition": "BlocklistDE == 1",
        "description": "IP атаковал серверы blocklist.de (SSH/FTP брутфорс)"
    },
    {
        "condition": "bruteforceblocker == 1",
        "description": "IP замечен в брутфорсе (bruteforceblocker)"
    },
    {
        "condition": "AbuseScore >= 70 and Count >= 5",
        "description": "Постоянный агрессор: высокий рейтинг + частые сработки"
    }
]

# По желанию пользователя: агрегация /24 — обновлённая логика (4 адреса)
DEFAULT_SUBNET_RULES = [
    {
        "condition": "blocked_ips >= 4",
        "description": "В подсети >= 4 заблокированных IP -> блокируется вся подсеть /24"
    },
    {
        "condition": "total_events >= 15 and blocked_ips >= 1",
        "description": ">= 15 событий в /24 и хотя бы 1 заблокированный IP -> блокируется /24"
    }
]

def _write_default(path, data):
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print(f"✅ Создан файл правил: {os.path.basename(path)}")
    except Exception as e:
        print(f"⚠️ Ошибка создания {path}: {e}")

def ensure_rules_exist():
    if not os.path.exists(IP_RULES_FILE):
        _write_default(IP_RULES_FILE, DEFAULT_IP_RULES)
    if not os.path.exists(SUBNET_RULES_FILE):
        _write_default(SUBNET_RULES_FILE, DEFAULT_SUBNET_RULES)

def load_ip_rules():
    ensure_rules_exist()
    try:
        with open(IP_RULES_FILE, 'r', encoding='utf-8') as f:
            rules = json.load(f)
            # ensure each rule has 'condition' and optional 'description'
            return [r for r in rules if isinstance(r, dict) and 'condition' in r]
    except Exception as e:
        print(f"⚠️ Ошибка чтения {IP_RULES_FILE}: {e}")
        return DEFAULT_IP_RULES

def load_subnet_rules():
    ensure_rules_exist()
    try:
        with open(SUBNET_RULES_FILE, 'r', encoding='utf-8') as f:
            rules = json.load(f)
            return [r for r in rules if isinstance(r, dict) and 'condition' in r]
    except Exception as e:
        print(f"⚠️ Ошибка чтения {SUBNET_RULES_FILE}: {e}")
        return DEFAULT_SUBNET_RULES
