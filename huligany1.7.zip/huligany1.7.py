#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
huligany1.7.py — версия 1.7
Основные изменения:
 - Вынесены стандартные критерии в ip_rules.json и subnet_rules.json (рядом со скриптом)
 - Добавлена поддержка комментариев к кастомным критериям
 - Сохраняет результаты в results/YYYY-MM-DD_HHMM/
 - Поддержка правил подсетей через subnet_rules.json (например blocked_ips >= 4)
 - Код разделён на модули utils.py и rules.py
"""

import os
import sys
import time
import json
import csv
import requests
import ipaddress
from collections import defaultdict, Counter
from datetime import datetime

# локальные модули
from utils import safe_eval_condition, get_network_24, update_progress, results_folder, timestamp_now, is_valid_ipv4
import rules

OUTPUT_VERSION = "huligany1.7"
FIREHOL_LISTS = [
    "firehol_level1.netset",
    "firehol_level2.netset",
    "firehol_level3.netset",
    "feodo.ipset",
    "bruteforceblocker.ipset"
]
FIREHOL_GITHUB_BASE = "https://raw.githubusercontent.com/firehol/blocklist-ipsets/master/"
CACHE_DIR = "firehol_cache"

# ---------------------------
# Конфиг — простая поддержка *.huligany1.7.config.json
# ---------------------------
def find_config_files():
    import glob
    pattern = os.path.join(os.path.dirname(os.path.abspath(__file__)), "*.huligany1.7.config.json")
    return sorted(glob.glob(pattern))

def load_config(config_path):
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"⚠️ Ошибка загрузки конфига {config_path}: {e}")
        return None

def save_config(config_data, name):
    filename = f"{name}.huligany1.7.config.json"
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(config_data, f, indent=2, ensure_ascii=False)
        print(f"✅ Конфиг сохранён: {path}")
        return True
    except Exception as e:
        print(f"❌ Не удалось сохранить конфиг: {e}")
        return False

# ---------------------------
# Ввод токенов и опций (как раньше)
# ---------------------------
def collect_tokens():
    print("\n🔑 Введите API-ключи AbuseIPDB")
    abuse_tokens = []
    while True:
        token = input("  AbuseIPDB токен (или Enter для пропуска): ").strip()
        if not token:
            break
        abuse_tokens.append(token)
        more = input("  Добавить ещё токен? [y/N]: ").strip().lower()
        if not (more == 'y' or more == 'yes'):
            break

    print("\n🔑 Введите токены ipinfo.io")
    ipinfo_tokens = []
    while True:
        token = input("  ipinfo.io токен (или Enter для пропуска): ").strip()
        if not token:
            break
        ipinfo_tokens.append(token)
        more = input("  Добавить ещё токен? [y/N]: ").strip().lower()
        if not (more == 'y' or more == 'yes'):
            break

    return abuse_tokens, ipinfo_tokens

def ask_analysis_options():
    print("\n⚙️ Настройка анализа")
    use_asn = input("Требуется ли определение ASN, страны и имени сети? [Y/n]: ").strip().lower()
    use_asn = use_asn in ("", "y", "yes")
    use_firehol = input("Выполнить проверку по спискам FireHOL? [y/N]: ").strip().lower()
    use_firehol = use_firehol in ("y", "yes")
    return use_asn, use_firehol

# ---------------------------
# Кастомные критерии — теперь поддерживаются как объект с comment
# ---------------------------
def collect_custom_criteria_interactive():
    """
    Возвращает список dict: [{"condition": "...", "comment": "..."}]
    """
    print("\n🎯 Кастомные критерии блокировки (интерактивно)")
    only_standard = input("Использовать ТОЛЬКО стандартные критерии? [Y/n]: ").strip().lower()
    if only_standard in ("", "y", "yes"):
        return True, []

    custom_criteria = []
    print("💡 Пример condition: (Country != 'US' and Country != 'NL') and AbuseScore >= 50")
    print("   Добавим к условию необязательный 'comment' — он попадёт в HTML и в header файла.")
    while True:
        condition = input("\n  Условие (или Enter для завершения): ").strip()
        if not condition:
            break
        comment = input("  Комментарий для этого правила (или Enter): ").strip()
        # синтаксическая проверка
        sample_row = {'Country': 'N/A', 'AbuseScore': 0, 'Count': 0, 'AS': 'N/A',
                      'Feodo_Original': 0, 'firehol_level1': 0, 'BlocklistDE': 0,
                      'bruteforceblocker': 0, 'AbuseReports': 0}
        try:
            # ast-check выполняется внутри safe_eval_condition — достаточно вызвать её
            _ = safe_eval_condition(condition, sample_row)
            custom_criteria.append({"condition": condition, "comment": comment})
            more = input("  Добавить ещё? [y/N]: ").strip().lower()
            if not (more == 'y' or more == 'yes'):
                break
        except Exception:
            print("❌ Некорректное выражение. Пропускаем.")
            more = input("  Попробовать снова? [y/N]: ").strip().lower()
            if not (more == 'y' or more == 'yes'):
                break

    use_standard_too = input("Использовать стандартные критерии ВМЕСТЕ с кастомными? [Y/n]: ").strip().lower()
    use_standard = use_standard_too in ("", "y", "yes")
    return use_standard, custom_criteria

# ---------------------------
# Загрузить внешние списки (как раньше)
# ---------------------------
def load_blocklist_de():
    ips = set()
    try:
        response = requests.get("https://lists.blocklist.de/lists/all.txt", timeout=15)
        if response.status_code == 200:
            for line in response.text.splitlines():
                ip = line.strip()
                if ip and not ip.startswith('#'):
                    try:
                        ipaddress.IPv4Address(ip)
                        ips.add(ip)
                    except:
                        continue
    except Exception as e:
        print(f"⚠️ Blocklist.de error: {e}")
    return ips

def load_feodo_original():
    ips = set()
    try:
        response = requests.get("https://feodotracker.abuse.ch/downloads/ipblocklist.csv", timeout=15)
        if response.status_code == 200:
            for line in response.text.splitlines():
                if line.startswith('#') or ',' not in line:
                    continue
                parts = line.split(',')
                if len(parts) >= 2:
                    ip = parts[1].strip('"')
                    try:
                        ipaddress.IPv4Address(ip)
                        ips.add(ip)
                    except:
                        continue
    except Exception as e:
        print(f"⚠️ Feodo error: {e}")
    return ips

def load_emerging_threats():
    ips = set()
    try:
        response = requests.get("https://rules.emergingthreats.net/blockrules/compromised-ips.txt", timeout=15)
        if response.status_code == 200:
            for line in response.text.splitlines():
                ip = line.strip()
                if ip and not ip.startswith('#'):
                    try:
                        ipaddress.IPv4Address(ip)
                        ips.add(ip)
                    except:
                        continue
    except Exception as e:
        print(f"⚠️ ET error: {e}")
    return ips

def download_firehol_list(list_name):
    url = FIREHOL_GITHUB_BASE + list_name
    os.makedirs(CACHE_DIR, exist_ok=True)
    file_path = os.path.join(CACHE_DIR, list_name)
    try:
        response = requests.get(url, timeout=30)
        if response.status_code == 200:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(response.text)
            # parse
            cidrs = []
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        if '/' not in line:
                            line = line + '/32'
                        try:
                            ipaddress.IPv4Network(line, strict=False)
                            cidrs.append(line)
                        except:
                            continue
            return cidrs
    except Exception as e:
        print(f"⚠️ Ошибка загрузки {list_name}: {e}")
    return []

def ask_firehol():
    print("\n" + "="*60)
    print("🔍 FireHOL Integration")
    print("Проверка по агрегированным блоклистам (GitHub, с CIDR)")
    print("Общий объём: ~10 МБ")
    choice = input("Выполнить проверку по FireHOL? [y/N]: ").strip().lower()
    if choice not in ('y', 'yes', '1'):
        return None

    os.makedirs(CACHE_DIR, exist_ok=True)
    cache_files = [f for f in os.listdir(CACHE_DIR) if f in FIREHOL_LISTS]
    if cache_files:
        mtime = os.path.getmtime(os.path.join(CACHE_DIR, cache_files[0]))
        cache_date = datetime.fromtimestamp(mtime).strftime('%Y-%m-%d')
        print(f"\n📁 Найдена локальная база от {cache_date}")
        update_choice = input("Использовать текущую [C] или обновить [U]? ").strip().lower()
        if update_choice.startswith('u'):
            for f in os.listdir(CACHE_DIR):
                os.remove(os.path.join(CACHE_DIR, f))
            print("🗑️ Старая база удалена.")
    else:
        print("\n📁 Локальная база не найдена. Будет загружена новая.")

    print("\n📥 Загрузка списков FireHOL...")
    firehol_sets = {}
    for name in FIREHOL_LISTS:
        print(f"  ⬇️ {name}")
        firehol_sets[name] = download_firehol_list(name)
        time.sleep(0.3)
    print("✅ FireHOL списки готовы.")
    return firehol_sets

# ---------------------------
# AbuseIPDB / IPinfo
# ---------------------------
current_ipinfo_token = 0
current_abuse_token = 0
abuse_cache = {}

def get_asn_for_subnet(subnet, ipinfo_tokens):
    global current_ipinfo_token
    if not ipinfo_tokens:
        return {'asn': 'N/A', 'as_name': 'N/A', 'cc': 'N/A'}
    for _ in range(len(ipinfo_tokens)):
        token = ipinfo_tokens[current_ipinfo_token]
        url = f"https://api.ipinfo.io/lite/{subnet}?token={token}"
        try:
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                data = response.json()
                raw_asn = data.get("asn", "N/A")
                asn = raw_asn[2:] if isinstance(raw_asn, str) and raw_asn.startswith("AS") else raw_asn
                as_name = data.get("as_name", "N/A")
                cc = data.get("country_code", "N/A")
                return {'asn': asn, 'as_name': as_name, 'cc': cc}
            elif response.status_code == 429:
                current_ipinfo_token = (current_ipinfo_token + 1) % len(ipinfo_tokens)
                time.sleep(1)
                continue
            else:
                break
        except Exception:
            current_ipinfo_token = (current_ipinfo_token + 1) % len(ipinfo_tokens)
            time.sleep(1)
            continue
    return {'asn': 'N/A', 'as_name': 'N/A', 'cc': 'N/A'}

def check_abuseipdb(ip, abuse_tokens):
    global current_abuse_token
    if ip in abuse_cache:
        return abuse_cache[ip]

    if not abuse_tokens:
        res = {"score": 0, "reports": 0}
        abuse_cache[ip] = res
        return res

    for _ in range(len(abuse_tokens)):
        token = abuse_tokens[current_abuse_token]
        try:
            response = requests.get(
                "https://api.abuseipdb.com/api/v2/check",
                headers={"Key": token, "Accept": "application/json"},
                params={"ipAddress": ip, "maxAgeInDays": 90},
                timeout=10
            )
            if response.status_code == 200:
                data = response.json().get("data", {})
                result = {
                    "score": data.get("abuseConfidenceScore", 0),
                    "reports": data.get("totalReports", 0)
                }
                abuse_cache[ip] = result
                return result
            elif response.status_code == 429:
                current_abuse_token = (current_abuse_token + 1) % len(abuse_tokens)
                time.sleep(1)
                continue
            else:
                break
        except Exception:
            current_abuse_token = (current_abuse_token + 1) % len(abuse_tokens)
            time.sleep(1)
            continue

    result = {"score": 0, "reports": 0}
    abuse_cache[ip] = result
    return result

# ---------------------------
# Определение action по ip_rules.json (проверяем правила по очереди)
# ---------------------------
def determine_action_and_reason_from_rules(row, ip_rules, use_standard=True, custom_criteria=None):
    """
    ip_rules: list of dicts {"condition": "...", "description": "..."}
    custom_criteria: list of dicts {"condition": "...", "comment": "..."}
    row: словарь с полями
    Возвращает (action, reason, is_custom)
    """
    custom_criteria = custom_criteria or []

    # сначала кастомные (если есть)
    for c in custom_criteria:
        cond = c.get('condition')
        if cond and safe_eval_condition(cond, row):
            reason = c.get('comment') or cond
            return "block", f"Custom: {cond}", True

    # затем правила из ip_rules (стандартные)
    if use_standard:
        for r in ip_rules:
            cond = r.get('condition')
            desc = r.get('description', '')
            if cond and safe_eval_condition(cond, row):
                return "block", desc or cond, False

    return "monitor", "Low risk — monitor", False

# ---------------------------
# Генерация блоклиста с учётом правил подсетей (subnet_rules.json)
# ---------------------------
def generate_blocklist(enriched_rows, subnet_total, subnet_rules):
    """
    enriched_rows: список словарей (каждый row имеет 'ip', 'subnet', 'action')
    subnet_total: dict subnet -> total events (Count/24)
    subnet_rules: list of dicts {"condition": "...", "description": "..."}
    Возвращает (block_ips_sorted, block_networks_list_of_tuples)
    """
    block_ips = set()
    block_networks = {}

    # подсчёт: blocked ips per subnet
    subnet_block_count = defaultdict(int)
    for row in enriched_rows:
        if row.get('action') == 'block':
            subnet_block_count[row['subnet']] += 1

    # оценим каждую подсеть согласно subnet_rules:
    for subnet, total_events in subnet_total.items():
        context = {
            'blocked_ips': subnet_block_count.get(subnet, 0),
            'total_events': total_events
        }
        applied = False
        for rule in subnet_rules:
            cond = rule.get('condition')
            desc = rule.get('description', '')
            if cond and safe_eval_condition(cond, context):
                network_cidr = f"{subnet}/24"
                block_networks[network_cidr] = desc or cond
                applied = True
                break
        if not applied:
            # если подсеть не заблокирована целиком — добавляем индивидуальные IP, которые имеют action block
            for row in enriched_rows:
                if row['subnet'] == subnet and row.get('action') == 'block':
                    block_ips.add(row['ip'])

    # удалим индивидуальные IP, попавшие в подсеть, которая уже заблокирована
    nets = set(block_networks.keys())
    block_ips_final = set()
    for ip in block_ips:
        subnet = get_network_24(ip)
        net_cidr = f"{subnet}/24" if subnet else None
        if net_cidr and net_cidr in nets:
            continue
        block_ips_final.add(ip)

    return sorted(block_ips_final), sorted([(k, v) for k, v in block_networks.items()])

def save_blocklist(block_ips, block_networks, results_dir, input_file, ip_rules, custom_criteria, use_standard):
    """
    Сохраняем blocklist + шапку с применёнными правилами в results_dir.
    """
    base = os.path.basename(input_file).rsplit('.', 1)[0]
    output_file = os.path.join(results_dir, f"{base}_{OUTPUT_VERSION}_blocklist.txt")
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(f"# Blocklist generated on {timestamp_now()}\n")
        f.write("# Criteria applied:\n")
        if custom_criteria:
            f.write("# CUSTOM CRITERIA:\n")
            for c in custom_criteria:
                cond = c.get('condition')
                comment = c.get('comment', '')
                f.write(f"#   {cond}  — {comment}\n")
        if use_standard:
            f.write("# STANDARD IP RULES (from ip_rules.json):\n")
            for r in ip_rules:
                cond = r.get('condition')
                desc = r.get('description', '')
                f.write(f"#   {cond}  — {desc}\n")
            f.write("#\n")
        f.write("# Subnet rules (from subnet_rules.json):\n")
        # load subnet rules for header
        subnet_rules = rules.load_subnet_rules()
        for r in subnet_rules:
            f.write(f"#   {r.get('condition')}  — {r.get('description','')}\n")
        f.write("#\n")
        f.write("# Hybrid list: individual IPs and /24 networks blocked by aggregation rules\n")
        f.write("#\n")
        if block_networks:
            f.write("# Networks /24 (with reason):\n")
            for net, reason in block_networks:
                f.write(f"{net}  # {reason}\n")
            f.write("\n")
        if block_ips:
            f.write("# Individual IPs:\n")
            for ip in block_ips:
                f.write(f"{ip}\n")
    print(f"✅ Blocklist saved: {output_file}")
    return output_file

# ---------------------------
# Отчёты CSV + HTML
# ---------------------------
def generate_reports(results_dir, input_file, enriched_rows, subnet_total, use_asn, ip_rules, custom_criteria, use_standard):
    base = os.path.basename(input_file).rsplit('.', 1)[0]
    output_csv = os.path.join(results_dir, f"{base}_{OUTPUT_VERSION}.csv")
    with open(output_csv, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f, quoting=csv.QUOTE_MINIMAL)
        headers = [
            'IP', 'Count', '/24', 'Count/24', 'AS', 'AS Name', 'Count/AS',
            'AbuseScore', 'AbuseReports', 'Feodo_Original', 'BlocklistDE', 'EmergingThreats'
        ]
        # determine firehol columns present
        # just include common names if present
        firehol_cols = ["firehol_level1", "firehol_level2", "firehol_level3", "feodo", "bruteforceblocker"]
        headers.extend([c for c in firehol_cols])
        headers.extend(['Action', 'Reason', 'CustomReason'])
        writer.writerow(headers)

        for row in enriched_rows:
            count_24 = subnet_total.get(row['subnet'], 0)
            if use_asn:
                count_as = sum(r['count'] for r in enriched_rows if r.get('asn') == row.get('asn'))
            else:
                count_as = subnet_total[row['subnet']]
            base_row = [
                row['ip'], row['count'], row['subnet'], count_24,
                row.get('asn'), row.get('as_name'), count_as,
                row.get('AbuseScore'), row.get('AbuseReports'),
                row.get('Feodo_Original', 0), row.get('BlocklistDE', 0), row.get('EmergingThreats', 0)
            ]
            # firehol cols
            for c in firehol_cols:
                base_row.append(row.get(c, 0))
            base_row.extend([row.get('action'), row.get('reason'), row.get('customreason','')])
            writer.writerow(base_row)
    print(f"✅ CSV: {output_csv}")

    # HTML
    output_html = os.path.join(results_dir, f"{base}_{OUTPUT_VERSION}_report.html")
    block_ips = [row['ip'] for row in enriched_rows if row.get('action') == 'block']
    cc_counter = Counter(row.get('Country','N/A') for row in enriched_rows if row.get('Country','N/A') != 'N/A')
    top_countries = cc_counter.most_common(12)
    chart_labels = [country for country, _ in top_countries]
    chart_counts = [count for _, count in top_countries]

    # prepare standard rules html
    std_html = "<ul>"
    if use_standard:
        for r in ip_rules:
            std_html += f"<li><code>{r.get('condition')}</code> — {r.get('description','')}</li>"
    else:
        std_html += "<li>Не используются</li>"
    std_html += "</ul>"

    # custom rules html with comments
    custom_html = "<ul>"
    if custom_criteria:
        for c in custom_criteria:
            cond = c.get('condition')
            comment = c.get('comment','')
            if comment:
                custom_html += f"<li><code>{cond}</code> — <i>{comment}</i></li>"
            else:
                custom_html += f"<li><code>{cond}</code></li>"
    else:
        custom_html += "<li>Не использованы</li>"
    custom_html += "</ul>"

    html_content = f"""<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Анализ хулиганов — {datetime.now().strftime('%Y-%m-%d')}</title>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
body {{ font-family: Arial, sans-serif; margin: 10px; }}
.summary {{ background: #f5f5f5; padding: 10px; border-radius: 5px; margin-bottom: 15px; font-size: 0.95em; }}
.card-row {{ display:flex; gap:12px; flex-wrap:wrap; }}
.card {{ background:#fff; padding:10px; border-radius:6px; box-shadow:0 1px 3px rgba(0,0,0,0.05); min-width:180px; }}
canvas {{ max-width:100%; height: auto; }}
table.dataTable tbody tr.block-standard {{ background-color: #ffdddd !important; }}
table.dataTable tbody tr.block-custom {{ background-color: #f3e5f5 !important; }}
table.dataTable tbody tr.monitor {{ background-color: #f7fff0 !important; }}
@media (max-width: 600px) {{
  .card-row {{ flex-direction: column; }}
}}
</style>
</head>
<body>
<h2>🛡️ Анализ подозрительных IP-адресов ({OUTPUT_VERSION})</h2>

<div class="summary card-row">
  <div class="card">
    <p><b>Дата:</b> {datetime.now().strftime('%Y-%m-%d %H:%M')}</p>
    <p><b>Всего IP:</b> {len(enriched_rows)}</p>
    <p><b>К блокировке (IP):</b> {len(block_ips)}</p>
  </div>
  <div class="card" style="flex:1">
    <canvas id="countryChart" height="120"></canvas>
  </div>
</div>

<div class="card" style="margin-bottom:10px;">
  <b>Кастомные критерии:</b>
  {custom_html}
  <b>Стандартные критерии (ip_rules.json):</b>
  {std_html}
</div>

<table id="results" class="display responsive nowrap" style="width:100%">
<thead>
<tr>
<th>IP</th><th>Count</th><th>/24</th><th>Count/24</th><th>AS</th><th>Count/AS</th>
<th>AS Name</th><th>Country</th><th>AbuseScore</th><th>Action</th><th>Reason</th><th>CustomReason</th>
</tr>
</thead>
<tbody>
"""

    for row in enriched_rows:
        if row.get('is_custom'):
            cls = "block-custom" if row.get('action') == 'block' else "monitor"
        else:
            cls = "block-standard" if row.get('action') == 'block' else "monitor"

        count_24 = subnet_total.get(row['subnet'], 0)
        if use_asn:
            count_as = sum(r['count'] for r in enriched_rows if r.get('asn') == row.get('asn'))
        else:
            count_as = subnet_total[row['subnet']]
        html_content += f"""
<tr class="{cls}">
  <td>{row.get('ip')}</td>
  <td>{row.get('count')}</td>
  <td>{row.get('subnet')}</td>
  <td>{count_24}</td>
  <td>{row.get('asn')}</td>
  <td>{count_as}</td>
  <td>{row.get('as_name')}</td>
  <td>{row.get('Country')}</td>
  <td>{row.get('AbuseScore')}</td>
  <td>{row.get('action')}</td>
  <td>{row.get('reason')}</td>
  <td>{row.get('customreason','')}</td>
</tr>"""

    html_content += """
</tbody>
</table>

<script>
const ctx = document.getElementById('countryChart').getContext('2d');
const chartLabels = """ + json.dumps(chart_labels) + """;
const chartData = """ + json.dumps(chart_counts) + """;

new Chart(ctx, {
    type: 'bar',
    data: {
        labels: chartLabels,
        datasets: [{
            label: 'IP count by country',
            data: chartData,
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: { beginAtZero: true }
        }
    }
});

$(document).ready(function() {
    $('#results').DataTable({
        pageLength: 25,
        searching: true,
        ordering: true,
        info: true,
        autoWidth: false,
        responsive: true
    });
});
</script>

</body>
</html>
"""

    with open(output_html, 'w', encoding='utf-8') as f:
        f.write(html_content)
    print(f"✅ HTML: {output_html}")

# ---------------------------
# Main
# ---------------------------
def main(input_file):
    start_time = time.time()

    # load rules (ip_rules.json, subnet_rules.json) — будут созданы, если их нет
    ip_rules = rules.load_ip_rules()
    subnet_rules = rules.load_subnet_rules()

    # config
    cfg = None
    print("\n🔎 Поиск конфигов...")
    configs = find_config_files()
    if configs:
        print("Найдены конфиги:")
        for i, c in enumerate(configs, 1):
            print(f"  {i}. {os.path.basename(c)}")
        print("  0. Продолжить без конфига")
        sel = input("Выберите номер конфига (0 пропустить): ").strip()
        try:
            idx = int(sel) - 1
            if idx >= 0 and idx < len(configs):
                cfg = load_config(configs[idx])
                print("✅ Загружен конфиг.")
        except Exception:
            cfg = None

    if cfg:
        abuse_tokens = cfg.get("abuseipdb_tokens", [])
        ipinfo_tokens = cfg.get("ipinfo_tokens", [])
        use_asn = cfg.get("use_asn", True)
        use_firehol = cfg.get("use_firehol", True)
        use_standard = cfg.get("use_standard_criteria", True)
        custom_criteria = cfg.get("custom_criteria", [])
    else:
        abuse_tokens, ipinfo_tokens = collect_tokens()
        use_asn, use_firehol = ask_analysis_options()
        use_standard, custom_criteria = collect_custom_criteria_interactive()

    # convert custom_criteria to list of dicts if user provided old format
    if isinstance(custom_criteria, list) and custom_criteria and isinstance(custom_criteria[0], str):
        # older format: list of strings -> convert to dicts without comment
        custom_criteria = [{"condition": c, "comment": ""} for c in custom_criteria]

    # firehol
    firehol_sets = None
    if use_firehol:
        firehol_sets = ask_firehol()

    print("📥 Загрузка остальных источников...")
    blocklist_set = load_blocklist_de()
    feodo_orig_set = load_feodo_original()
    et_set = load_emerging_threats()

    # read input file (tab-separated: ip<TAB>count)
    ip_counts = []
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) < 2:
                continue
            ip = parts[0].strip()
            try:
                count = int(parts[1].strip())
            except Exception:
                continue
            if is_valid_ipv4(ip):
                ip_counts.append((ip, count))

    if not ip_counts:
        print("❌ Нет валидных записей.")
        return

    # подсчёт по /24
    subnet_total = defaultdict(int)
    ip_with_subnet = []
    for ip, count in ip_counts:
        subnet = get_network_24(ip)
        if subnet:
            subnet_total[subnet] += count
            ip_with_subnet.append((ip, count, subnet))

    # ASN
    subnet_asn_map = {}
    if use_asn:
        unique_subnets = list(subnet_total.keys())
        print(f"🔍 Уникальных подсетей: {len(unique_subnets)}")
        for i, subnet in enumerate(unique_subnets, 1):
            update_progress(i, len(unique_subnets), subnet, prefix="ASN: ")
            subnet_asn_map[subnet] = get_asn_for_subnet(subnet, ipinfo_tokens)
            time.sleep(0.2)
    else:
        for ip, count, subnet in ip_with_subnet:
            if subnet not in subnet_asn_map:
                subnet_asn_map[subnet] = {'asn': 'N/A', 'as_name': 'N/A', 'cc': 'N/A'}

    # enrichment
    total_ips = len(ip_with_subnet)
    print(f"\n🛡️ Проверка {total_ips} IP...")
    enriched_rows = []
    for idx, (ip, count, subnet) in enumerate(ip_with_subnet, 1):
        update_progress(idx, total_ips, ip, prefix="Threats: ")
        abuse = check_abuseipdb(ip, abuse_tokens)
        in_blocklist = 1 if ip in blocklist_set else 0
        in_feodo_orig = 1 if ip in feodo_orig_set else 0
        in_et = 1 if ip in et_set else 0

        # firehol flags
        firehol_flags = {}
        if firehol_sets:
            for name in FIREHOL_LISTS:
                short_name = name.replace(".netset", "").replace(".ipset", "")
                firehol_flags[short_name] = 1 if any(ipaddress.IPv4Address(ip) in ipaddress.IPv4Network(c, strict=False) for c in firehol_sets.get(name, [])) else 0
        else:
            for name in FIREHOL_LISTS:
                short_name = name.replace(".netset", "").replace(".ipset", "")
                firehol_flags[short_name] = 0

        info = subnet_asn_map.get(subnet, {'asn': 'N/A', 'as_name': 'N/A', 'cc': 'N/A'})
        asn = info['asn']
        row_data = {
            'ip': ip,
            'count': count,
            'subnet': subnet,
            'asn': asn,
            'as_name': info.get('as_name', 'N/A'),
            'Country': info.get('cc', 'N/A'),
            'AbuseScore': abuse['score'],
            'AbuseReports': abuse['reports'],
            'Feodo_Original': in_feodo_orig,
            'BlocklistDE': in_blocklist,
            'EmergingThreats': in_et,
            **firehol_flags
        }
        # aliases expected by rules
        row_data['Count'] = count
        row_data['AS'] = asn

        action, reason, is_custom = determine_action_and_reason_from_rules(row_data, ip_rules, use_standard, custom_criteria)
        row_data['action'] = action
        row_data['reason'] = reason
        row_data['customreason'] = reason if is_custom else ""
        row_data['is_custom'] = is_custom
        enriched_rows.append(row_data)
        time.sleep(0.15)

    # generate blocklist with subnet rules
    block_ips, block_networks = generate_blocklist(enriched_rows, subnet_total, subnet_rules)

    # create results folder with timestamp
    res_dir = results_folder()
    # save blocklist
    save_blocklist(block_ips, block_networks, res_dir, input_file, ip_rules, custom_criteria, use_standard)

    # offer saving config
    save_cfg = input("\nСохранить настройки в конфиг? [y/N]: ").strip().lower()
    if save_cfg in ("y", "yes"):
        cfg_name = input("Введите имя конфига (без расширения): ").strip()
        if cfg_name:
            to_save = {
                "abuseipdb_tokens": abuse_tokens,
                "ipinfo_tokens": ipinfo_tokens,
                "use_asn": use_asn,
                "use_firehol": use_firehol,
                "use_standard_criteria": use_standard,
                "custom_criteria": custom_criteria
            }
            save_config(to_save, cfg_name)

    # generate reports
    print("\n⏳ Генерация отчётов...")
    generate_reports(res_dir, input_file, enriched_rows, subnet_total, use_asn, ip_rules, custom_criteria, use_standard)

    elapsed = time.time() - start_time
    print(f"\n✅ Готово! Время выполнения: {elapsed:.2f} секунд")
    print(f"Результаты в папке: {res_dir}")

# ---------------------------
# Запуск
# ---------------------------
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Использование: python huligany1.7.py <input.txt>")
        sys.exit(1)
    # ensure rules default files exist
    rules.ensure_rules_exist()
    main(sys.argv[1])
