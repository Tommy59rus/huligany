#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
utils.py — вспомогательные функции для huligany1.7
"""

import ast
import ipaddress
import os
import sys
import time
from datetime import datetime

# ---------------------------
# AST-безопасная оценка условий
# ---------------------------
ALLOWED_NODES = (
    ast.Expression, ast.BoolOp, ast.UnaryOp, ast.Compare,
    ast.Name, ast.Load, ast.Constant,
    ast.And, ast.Or, ast.Not, ast.Eq, ast.NotEq,
    ast.Gt, ast.GtE, ast.Lt, ast.LtE
)

def _coerce_numeric(a):
    if isinstance(a, (int, float)):
        return a
    if isinstance(a, str):
        s = a.strip()
        if s.isdigit() or (s.startswith('-') and s[1:].isdigit()):
            try:
                return int(s)
            except Exception:
                pass
        try:
            if '.' in s:
                return float(s)
        except Exception:
            pass
    return a

def safe_eval_condition(condition_str, row):
    """
    Безопасно оценивает логическое выражение (Python-like) на основе данных из row (dict).
    Возвращает True/False. Любая ошибка — False.
    Разрешены только узлы, указанные в ALLOWED_NODES.
    """
    if not condition_str or not condition_str.strip():
        return False
    try:
        node = ast.parse(condition_str, mode='eval')
    except Exception:
        return False

    for sub in ast.walk(node):
        if not isinstance(sub, ALLOWED_NODES):
            return False

    def eval_node(n):
        if isinstance(n, ast.Expression):
            return eval_node(n.body)
        if isinstance(n, ast.BoolOp):
            if isinstance(n.op, ast.And):
                return all(eval_node(v) for v in n.values)
            elif isinstance(n.op, ast.Or):
                return any(eval_node(v) for v in n.values)
            else:
                raise ValueError("Unsupported BoolOp")
        if isinstance(n, ast.UnaryOp):
            if isinstance(n.op, ast.Not):
                return not eval_node(n.operand)
            else:
                raise ValueError("Unsupported UnaryOp")
        if isinstance(n, ast.Compare):
            left = eval_node(n.left)
            for op, comp in zip(n.ops, n.comparators):
                right = eval_node(comp)
                left_coerced = _coerce_numeric(left)
                right_coerced = _coerce_numeric(right)
                try:
                    if isinstance(op, ast.Eq):
                        ok = left_coerced == right_coerced
                    elif isinstance(op, ast.NotEq):
                        ok = left_coerced != right_coerced
                    elif isinstance(op, ast.Gt):
                        ok = left_coerced > right_coerced
                    elif isinstance(op, ast.GtE):
                        ok = left_coerced >= right_coerced
                    elif isinstance(op, ast.Lt):
                        ok = left_coerced < right_coerced
                    elif isinstance(op, ast.LtE):
                        ok = left_coerced <= right_coerced
                    else:
                        raise ValueError("Unsupported comparison")
                except Exception:
                    try:
                        ok = str(left) == str(right) if isinstance(op, ast.Eq) else str(left) != str(right)
                    except Exception:
                        ok = False
                left = right
                if not ok:
                    return False
            return True
        if isinstance(n, ast.Name):
            return row.get(n.id, None)
        if isinstance(n, ast.Constant):
            return n.value
        raise ValueError("Unsupported AST node")

    try:
        return bool(eval_node(node))
    except Exception:
        return False

# ---------------------------
# Полезное: получить /24 сетевой адрес от IP
# ---------------------------
def get_network_24(ip_str):
    try:
        ip = ipaddress.IPv4Address(ip_str.strip())
        if ip.is_private:
            return None
        network = ipaddress.IPv4Network(f"{ip}/24", strict=False)
        return str(network.network_address)
    except Exception:
        return None

# ---------------------------
# Простой прогресс-бар
# ---------------------------
def update_progress(current, total, item, prefix=""):
    msg = f"{prefix}[{current}/{total}] {item}"
    sys.stdout.write("\r" + msg.ljust(80))
    sys.stdout.flush()
    if current == total:
        sys.stdout.write("\n")

# ---------------------------
# Форматирование времени/папок результата
# ---------------------------
def results_folder(base="results"):
    ts = datetime.now().strftime("%Y-%m-%d_%H%M")
    path = os.path.join(base, ts)
    os.makedirs(path, exist_ok=True)
    return path

def timestamp_now():
    return datetime.now().strftime("%Y-%m-%d %H:%M")

# ---------------------------
# Небольшая утилита: проверить валидность IPv4
# ---------------------------
def is_valid_ipv4(ip):
    try:
        ipaddress.IPv4Address(ip)
        return True
    except Exception:
        return False
